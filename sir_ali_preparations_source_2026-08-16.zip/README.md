# Sir Ali Preparations - Academic Management Portal

A full-featured Home & Online Tuitions Academic Management System built with React 19, TypeScript, and Tailwind CSS.

## 🚀 How to Run Locally

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start development server**:
   ```bash
   npm run dev
   ```
   Open http://localhost:3000 in your browser.

3. **Build for Production / GitHub Pages**:
   ```bash
   npm run build
   ```
   The production files will be in the `dist/` folder.

## 🌐 Deploy to GitHub Pages

1. Create a repository on GitHub and push all these files.
2. Go to **Settings** > **Pages**.
3. Under **Build and deployment**, select **GitHub Actions** (or deploy the `dist/` folder).
